#!/bin/sh
#常量类型
master_type="Master"
slave_type="Slave"
sentinel_type="Sentinel"
masterServer_divd="&8&"
#节点记录数
rec_num=0
#REDIS NODE节点数
redis_num=0
#处理的机器信息是否当前机器 
is_currentserver="false"
#是否安装主REDIS  is_install_master
is_install_master="N"
#是否安装备REDIS  is_install_slave
is_install_slave="N"
#是否安装REDIS监控  is_install_sentinel
is_install_sentinel="N"
#主Redis节点数
masternodenum=""
#主Redis端口
masternodeport=""
#主Redis内存数
masternodemomery=""
#备Redis节点数
slavenodenum=""
#备Redis端口
slavenodeport=""
#备Redis内存数
slavenodemomery=""
#sentinel端口
sentinelport=""
#缺省sentinel端口
default_sentinelport="26379"
#客户端redis.servers.names
redis_servers_names=""
#客户端redis.Sentinel.servers
redis_Sentinel_servers=""
#主Redis数组
declare -a masterServerArray
#Redis节点IP
redis_node_ip=""

#当前机器IP
#_rhost=$('ifconfig'|'grep' 'inet addr:'|'grep' -v '127.0.0.1'|'cut' -d: -f2|'awk' '{print $1}')
_rhost=$2


#处理Redis主服务器相关内容
handlemaster()
{
 if [ "$is_install_master" = "Y" ]; then  
   mv ./bin/start-master?.sh ./bin/start-master$masternodenum.sh
   mv ./bin/stop-master?.sh ./bin/stop-master$masternodenum.sh
   mv ./config/redis-master?.conf ./config/redis-master$masternodenum.conf
   filename=./bin/start-master$masternodenum.sh
   sourstr=redis-masterX.conf
   deststr=redis-master$masternodenum.conf
   replacefile
   filename=./bin/stop-master?.sh
   sourstr=%localip%
   deststr=$_rhost
   replacefile
   sourstr=%masternodeport%
   deststr=$masternodeport
   replacefile
   filename=./config/redis-master?.conf
   sourstr=%masternodeport%
   deststr=$masternodeport
   replacefile
   if [ $masternodemomery != "" -a $masternodemomery != "2" ]; then
      echo " ">>./config/redis-master$masternodenum.conf
      echo " ">>./config/redis-master$masternodenum.conf
      echo "maxmemory  ${masternodemomery}gb">>./config/redis-master$masternodenum.conf      
   fi   
 else
   rm ./bin/start-master?.sh
   rm ./bin/stop-master?.sh
   rm ./config/redis-master?.conf
 fi
}

#处理Redis备服务器相关内容
handleslave()
{
 if [ "$is_install_slave" = "Y" ]; then
   mv ./bin/start-slave?.sh ./bin/start-slave$slavenodenum.sh
   mv ./bin/stop-slave?.sh ./bin/stop-slave$slavenodenum.sh
   mv ./config/redis-slave?.conf ./config/redis-slave$slavenodenum.conf
   filename=./bin/start-slave$slavenodenum.sh
   sourstr=redis-slaveX.conf
   deststr=redis-slave$slavenodenum.conf
   replacefile
   filename=./bin/stop-slave?.sh
   sourstr=%localip%
   deststr=$_rhost
   replacefile
   sourstr=%slavenodeport%
   deststr=$slavenodeport
   replacefile
   filename=./config/redis-slave?.conf
   sourstr=%slavenodeport%
   deststr=$slavenodeport
   replacefile  
   sourstr=%slaveof%
   deststr=$('echo' ${masterServerArray[$slavenodenum]}|'awk' -F$masterServer_divd  '{print $2" "$3}')           
   replacefile
   if [ $slavenodemomery != "" -a $slavenodemomery != "2" ]; then
      echo " ">>./config/redis-slave$slavenodenum.conf
      echo " ">>./config/redis-slave$slavenodenum.conf
      echo "maxmemory  ${slavenodemomery}gb">>./config/redis-slave$slavenodenum.conf     
   fi  
 else
   rm ./bin/start-slave?.sh
   rm ./bin/stop-slave?.sh
   rm ./config/redis-slave?.conf
 fi
}

#处理Redis监控服务器相关内容
handlesentinel()
{ 
 if [ "$is_install_sentinel" = "Y" ]; then  
   filename=./bin/stopSentinel.sh
   sourstr=%localip%
   deststr=$_rhost
   replacefile  

   filename=./config/sentinel.conf
   sourstr=%sentinelport%
   if [ "$sentinelport" = "" ]; then
      deststr=$default_sentinelport
   else
      deststr=$sentinelport
   fi   
   replacefile

   filename=./bin/stopSentinel.sh
   sourstr=%sentinelport%
   replacefile

   for var in ${masterServerArray[*]}; do
    mastername="master$('echo' $var|'awk' -F$masterServer_divd  '{print $1}')"
    echo "sentinel monitor $mastername $('echo' $var|'awk' -F$masterServer_divd  '{print $2" "$3}') 1">>./config/sentinel.conf
    echo "sentinel down-after-milliseconds $mastername 10000">>./config/sentinel.conf
    echo "sentinel failover-timeout $mastername 60000">>./config/sentinel.conf
    echo "sentinel config-epoch $mastername 1">>./config/sentinel.conf
    echo " ">>./config/sentinel.conf
    echo " ">>./config/sentinel.conf
    redis_servers_names=$redis_servers_names$mastername":10:200:-;"
   done
 else
   rm ./bin/startSentinel.sh
   rm ./bin/stopSentinel.sh
   rm ./config/sentinel.conf
 fi
}

#文件内容替换
replacefile()
{
  sed -i "s/$sourstr/$deststr/"  $filename
}

#配置信息处理
infoHandle(){
    _rowip=$(echo $_rowData|awk -F, '{print $1}')
    #rec_num=$[rec_num+1]
    preHandleServerInfo  
    rec_num=$[rec_num+1]
 }
#单条信息预处理
preHandleServerInfo(){ 
  #node_rec_num=$[ (rec_num - 1) % 3 ]
  node_rec_num=$[ rec_num % 3 ]
  if [ "$is_currentserver" = "false" -a "$node_rec_num" = 1 ]; then
      if [  "$_rowip" = "" ]; then
        echo $rec_num" row server ip  is  null,please check your excel!"
        exit
      fi
      if [ "$_rowip" = "$_rhost" ]; then
           is_currentserver=true
      else
           is_currentserver=false
      fi 
      redis_node_ip=$_rowip      
  fi
  currentServerInfoHandle  
  #echo "rhost="$_rhost" rowip="$_rowip" is_currentserver="$is_currentserver " rec_num="$rec_num " node_rec_num="$node_rec_num 
  if [ "$node_rec_num" = 0 ]; then
       is_currentserver=false
  fi
}

#单条信息处理
currentServerInfoHandle(){
    _server_type=$(echo $_rowData|awk -F, '{print $2}')
    _is_install=$(echo $_rowData|awk -F, '{print $3}')
    _nodenum=$(echo $_rowData|awk -F, '{print $4}')
    _nodeport=$(echo $_rowData|awk -F, '{print $5}')
   #检查Master/Slave/Sentinel是否为空
   if [  "$_server_type" = "" ]; then
        echo $rec_num" Master/Slave/Sentinel is  null,please check your excel!"
        exit
   fi
   #检查是否安装是否为空
   if [  "$_is_install" = "" ]; then
        echo $rec_num" Y/N is  null,please check your excel!"
        exit
   fi

   #当选择按照主或者备时，检查节点数、端口是否为空
   if [  "$_server_type" != "$sentinel_type" -a "$_is_install" = "Y" ]; then
        if [  "$_nodenum" = "" ]; then
           echo $rec_num" nodenum is  null,please check your excel!"
           exit
        fi
	if [  "$_nodeport" = "" ]; then
           echo $rec_num" nodeport is  null,please check your excel!"
           exit
        fi
   fi


   if [ "$is_currentserver" = "true" ]; then     
      case "$_server_type" in
        "$master_type")   is_install_master=$_is_install  
	                  masternodenum=$_nodenum
			  masternodeport=$_nodeport
			  masternodemomery=$(echo $_rowData|awk -F, '{print $6}');;
        "$slave_type")    is_install_slave=$_is_install 
                          slavenodenum=$_nodenum
			  slavenodeport=$_nodeport
			  slavenodemomery=$(echo $_rowData|awk -F, '{print $6}');;
        "$sentinel_type") is_install_sentinel=$_is_install 
	                  sentinelport=$_nodeport ;; 
      esac    
   fi
   if [ "$_server_type" = "$master_type" -a "$_is_install" = "Y" ]; then          
          masterServerArray[$_nodenum]="${_nodenum}$masterServer_divd$_rowip$masterServer_divd$_nodeport"
   fi
   if [ "$_server_type" = "$sentinel_type" -a "$_is_install" = "Y" ]; then 
         if [ "$_nodeport" = "" ]; then
             _nodeport=$default_sentinelport        
         fi
	 if [ "$_rowip" = "" ]; then
             _rowip=$redis_node_ip        
         fi
         redis_Sentinel_servers=$redis_Sentinel_servers$_rowip":"$_nodeport";"
   fi
}



if [ $# != 3 ]; then
    echo "please input config file path and name!"
    exit
else   
    _file=$1
fi

filename=$_file
sourstr=
deststr=""
replacefile

while read line
do
  _rowData=$line
  infoHandle  
done < $_file

echo  "is_install_master="$is_install_master
echo  "is_install_slave="$is_install_slave 
echo  "is_install_sentinel="$is_install_sentinel



echo "masternodenum="$masternodenum
echo "masternodeport="$masternodeport
echo "masternodemomery="$masternodemomery
echo "slavenodenum="$slavenodenum
echo "slavenodeport="$slavenodeport
echo "slavenodemomery="$slavenodemomery
echo "sentinelport="$sentinelport
echo "slaveof="${masterServerArray[$slavenodenum]}
for var in ${masterServerArray[*]};
do
   echo "var is $var"
done


echo "start handle master"
handlemaster
echo "handle slave finish"

echo "start handle slave"
handleslave
echo "handle slave finish"

echo "start handle sentinel"
handlesentinel
echo "end handle sentinel"

cd bin
sh_file_num=0
for file in ./start* ;
do
   if [ $sh_file_num = 0 ]; then
      echo  "#!/bin/sh">>startAll.sh
   fi
   echo  "$file">>startAll.sh
   let sh_file_num++
done
if [ $sh_file_num -lt 2 ]; then
   rm startAll.sh
fi

sh_file_num=0
for file in ./stop* ;
do
   if [ $sh_file_num = 0 ]; then
      echo  "#!/bin/sh">>stopAll.sh
   fi
   echo  "$file">>stopAll.sh
   let sh_file_num++
done
if [ $sh_file_num -lt 2 ]; then
   rm stopAll.sh
fi

cd ..

echo "">>./clientconfig.txt
echo "">>./clientconfig.txt
echo "redis.servers.names="$redis_servers_names>>./clientconfig.txt
echo "redis.Sentinel.servers="$redis_Sentinel_servers>>./clientconfig.txt

tar xzf $3".tar.gz"
cd  $3
make
mv  ../bin   .
mv  ../config  .
mkdir rdb
chmod  +x  bin/*.sh
rm redis.conf
rm sentinel.conf
rm ../$3".tar.gz"
rm ../install.sh
echo "this is end!"



